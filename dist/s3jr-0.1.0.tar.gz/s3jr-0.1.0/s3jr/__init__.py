"""
S3Jr.

A Simpler S3 Wrapper.
"""

__version__ = "0.1.0"
__author__ = 'Kishore'
__credits__ = 'Tealpod'